MobiCar
================

Phase one Description
------------------------

Our mission was to make a carbot that could be controlled with a Bluetooth module and a smart android phone, using a mobile application. So we got an ARDUINO for the controlling process, as it's a very simple and easy open source Microcontoller, we used ARDUINO Mega 2560 as it has enough analog and digital pins, also it has a lot of communication protocols pins with many serial communication pins .

We then used a Bluetooth module -model no. HC-05- as it’s cheap, high quality and easy to work with, also for the car chassis we used a 4WD chassis for perfect control and high speed if needed. The link between the motors and the ARDUINO was the H-Bridge, we used model L298N it's cheap and does the job well as needed. The motors voltage was 12 volt, it enables us to control the speed of the motors using PWM from ARDUINO in addition to the direction of rotation of the motors to control the directions of movement of the car. As for the direction controlling we used the rovers techniques of turning in the two directions it's a simple and easy way all in addition to its accuracy.
